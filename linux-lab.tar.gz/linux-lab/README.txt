LINUX-LAB: katalog ćwiczeniowy do lekcji 9 (Linux dla bezpieczeństwa, część 1)
Cyber Security Engineer, LearnIT

Wszystkie dane w tym katalogu są SYNTETYCZNE: zmyślone osoby, adresy IP
z zakresów dokumentacyjnych (192.0.2.0/24, 198.51.100.0/24, 203.0.113.0/24),
domeny zarezerwowane (example.com, example.org). Nie ma tu prawdziwych haseł
ani tokenów. Możesz spokojnie ćwiczyć.

Zasady:
1. Pracuj jako zwykły użytkownik, bez sudo.
2. Najpierw rozpoznaj, potem zmieniaj.
3. Najpierw pracuj na kopii, potem na materiale źródłowym.
4. Najpierw ogranicz zakres polecenia (-print, tar -t), potem zapisuj lub usuwaj.

Co tu jest:
  users.csv                 lista kont (CSV, separator przecinek)
  logs/                     logi aplikacji i logowania
  reports/                  raporty (uwaga na wielkość liter w nazwach)
  config/service.conf       plik konfiguracyjny do ćwiczeń z nano i vim
  downloads/                miejsce na pobrane pliki
  archives/                 archiwum do sprawdzenia PRZED rozpakowaniem
  case notes/               katalog ze spacją w nazwie
  -evidence.txt             plik, którego nazwa zaczyna się od myślnika
  .analyst-note             plik ukryty (zobaczysz go przez ls -a)

Zadanie podsumowujące (z podręcznika, rozdział 10):
  1. Utwórz case-001 z podkatalogami evidence, notes i output.
  2. Znajdź wszystkie pliki .log bez przeszukiwania ich treści.
  3. Sprawdź typ i rozmiar logu logs/auth.log.
  4. Wyszukaj bez rozróżniania wielkości liter linie zawierające "failed".
  5. Zapisz dopasowania do case-001/output/failed.txt.
  6. Zapisz komunikaty błędów do osobnego pliku.
  7. Dopisz liczbę znalezionych linii do case-001/output/summary.txt.
  8. Dodaj w nano krótką notatkę opisującą wykonane działania.
  9. Utwórz archiwum case-001.tar.gz.
 10. Wyświetl zawartość archiwum bez rozpakowywania.

Oceniany jest sposób pracy: umiesz wyjaśnić każde użyte polecenie.
